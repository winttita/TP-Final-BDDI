USE TP_BBDDI_FRANK_WINTER
GO
/*6. Escriba un procedimiento almacenado para identificar si existen tareas no realizadas
dado un �rbol en particular y un tipo de tareas. El procedimiento debe devolver:
a. Como par�metro de salida, la fecha de la pr�xima tarea del tipo indicado a
realizarse sobre el �rbol, si existiera.
b. Debe retornar (como valor de retorno) la cantidad de tareas pendientes de
realizar para el tipo de tarea y �rbol proporcionados.
Incluya dos ejemplos de ejecuci�n del procedimiento (encontrando y no encontrandotareas) y muestre los valores devueltos en cada caso.*/

CREATE OR ALTER PROCEDURE sp_AnalizarTareasArbol
	@idArbol INT,
	@idTipoTarea INT,
	@FechaProxima DATE OUTPUT
AS
BEGIN
	--punto a
	SELECT TOP 1 @FechaProxima=T.FechaEstimada
	FROM TareaArbol TA
	JOIN Tarea T ON T.idTarea=TA.idTarea
	WHERE TA.idArbol=@idArbol 
		  AND T.idTipoTarea=@idTipoTarea 
		  AND T.FechaRealizado IS NULL 
		  AND T.FechaEstimada>=GETDATE()
	ORDER BY T.FechaEstimada ASC;
	--punto b
	DECLARE @CantidadPendientes INT;
	SELECT @CantidadPendientes = COUNT(T.idTarea)
    FROM TareaArbol TA
    INNER JOIN Tarea T ON TA.idTarea = T.idTarea
    WHERE TA.idArbol = @idArbol 
      AND T.idTipoTarea = @idTipoTarea
      AND T.FechaRealizado IS NULL;
	RETURN @CantidadPendientes;
END
GO

--Caso 1 encontrando tareas
DECLARE @FechaSalida DATE;      -- Variable para atrapar el OUTPUT
DECLARE @CantidadTareas INT;   -- Variable para atrapar el RETURN

EXEC @CantidadTareas = sp_AnalizarTareasArbol 
    @idArbol = 11,                
    @idTipoTarea = 1,             
    @FechaProxima = @FechaSalida OUTPUT;

-- Mostrar resultados
SELECT 
    'Caso Encontrado' AS Escenario,
    @FechaSalida AS [Fecha Pr�xima Tarea],
    @CantidadTareas AS [Tareas Pendientes];
GO

--Caso 2 No encontradoDECLARE @FechaSalida2 DATE;
DECLARE @CantidadRetorno2 INT;

-- Ejecuci�n
EXEC @CantidadRetorno2 = sp_AnalizarTareasArbol 
    @idArbol = 1,                -- ID de un �rbol sin tareas o inexistente
    @idTipoTarea = 1,
    @FechaProxima = @FechaSalida2 OUTPUT;

-- Mostrar resultados
SELECT 
    'Caso NO Encontrado' AS Escenario,
    @FechaSalida2 AS [Fecha Pr�xima Tarea], -- Deber�a ser NULL
    @CantidadRetorno2 AS [Cantidad Pendientes]; -- Deber�a ser 0
GO
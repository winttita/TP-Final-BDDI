USE TP_BBDDI_FRANK_WINTER
GO
/*a. Mostrar informaci�n de los reclamos. Se desea saber la fecha de cada uno,
el c�digo del �rbol asociado al reclamo, la cantidad de d�as que se tard� en
asignar la tarea y la cantidad de d�as que se tard� en resolver el mismo. Sino tiene tarea asignada o no fue resuelto calcular los d�as hasta la fechaactual.*/
CREATE VIEW v_InfoReclamos AS
	SELECT R.Fecha, A.Codigo, 
		DATEDIFF(DAY, R.Fecha, ISNULL(T.FechaRealizado, GETDATE())) AS [Tiempo de Resolucion], 
		DATEDIFF(DAY, R.Fecha, ISNULL(R.FechaAsignacionTarea, GETDATE())) AS [Tiempo de Asignacion]
	FROM Reclamos R
	JOIN Arbol A ON A.idArbol=R.idArbol
	JOIN Tarea T ON T.idtarea=R.idTarea
GO
SELECT * FROM v_InfoReclamos;
SELECT * FROM v_InfoReclamos WHERE [Tiempo de Asignacion] > 10;
/*b. Resumen de tareas ya realizadas seg�n su tipo. Se desea saber la fecha de
la primer y �ltima tarea de cada tipo y la cantidad de tareas realizadas*/
CREATE VIEW v_TareasRealizadas AS
	SELECT TT.Descripcion, 
		MIN(T.FechaRealizado) AS [Primera Fecha Realizada], 
		MAX(T.FechaRealizado) AS [Ultima Fecha Realizada], 
		COUNT(*) AS [Cantidad Tareas]
	FROM Tarea T
	JOIN TipoTarea TT ON T.idTipoTarea=TT.idTipoTarea
	WHERE T.FechaRealizado<=GETDATE()
	GROUP BY TT.Descripcion
GO
SELECT * FROM v_TareasRealizadas;
SELECT * FROM v_TareasRealizadas WHERE [Cantidad Tareas] > 2;
GO
